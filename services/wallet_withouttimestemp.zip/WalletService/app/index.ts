import { expressApp } from '../../../shared/lib/system/expressApp'

// Add service specific middleware here

export default expressApp
