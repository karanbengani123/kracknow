export interface IWallet {
  orderAmount: number
}
