export interface IStudentaddmoneyRequest {
  transactionId: number;
  transactionImage: string;
  amount: number

}
