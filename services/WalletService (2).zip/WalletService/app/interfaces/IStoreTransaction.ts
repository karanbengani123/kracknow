export interface IStoreTransaction {
  paymentMode: string
  orderId: string
  referenceId: string
  orderAmount: string
  txStatus: string
  txTime: string
  transactionType: string
}
