import { IStoreTransaction } from './IStoreTransaction'
import { IWallet } from './IWallet'
import { IAdminAddMoney } from './IAdminAddMoney'
import { IStudentWithdrawRequest } from './IStudentWithdrawRequest'
import { IStudentaddmoneyRequest } from './IStudentaddmoneyRequest'
export { IStoreTransaction, IWallet, IAdminAddMoney, IStudentWithdrawRequest, IStudentaddmoneyRequest }
