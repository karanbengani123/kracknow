import { common, studentAttributesWithoutFAndSName } from './excludeAttributes'

export { common, studentAttributesWithoutFAndSName }
