export const timestemp = async () => {
  return {
    message: Date.now(),
  };
};
