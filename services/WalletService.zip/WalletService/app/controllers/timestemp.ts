import { SUCCESSFUL } from "../../../../shared/constants/httpSuccessMessages";
import {
  Student,
  Wallet,
  WalletTransaction,
} from "../../../../shared/database/models";
import { parseLimitOffsetFromRequest } from "../../../../shared/helpers/parseLimitOffsetFromRequest";
import { IControllerParams } from "../../../../shared/interfaces/IControllerParams";
import { studentAttributesWithoutFAndSName } from "../constant";
import { walletAllHistoryExcludeAttributes } from "../constant/excludeAttributes";
import { Op } from "sequelize";

export const timestemp = async (
  params: IControllerParams<null>
) => {
    // var date = new Date();

  return {
    message: Date.now(),
  };
};
