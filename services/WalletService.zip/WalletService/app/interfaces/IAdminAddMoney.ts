export interface IAdminAddMoney {
  amount: number;
  studentUUID: string
}
